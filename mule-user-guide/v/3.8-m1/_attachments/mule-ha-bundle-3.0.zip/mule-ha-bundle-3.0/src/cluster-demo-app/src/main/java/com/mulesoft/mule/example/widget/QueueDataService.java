/*
 * $Id$
 * --------------------------------------------------------------------------------------
 *
 * (c) 2003-2010 MuleSoft, Inc. This software is protected under international copyright
 * law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 * (or other master license agreement) separately entered into in writing between you and
 * MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package com.mulesoft.mule.example.widget;

import org.mule.api.MuleContext;
import org.mule.api.config.MuleProperties;
import org.mule.api.construct.FlowConstruct;
import org.mule.api.context.MuleContextAware;
import org.mule.api.endpoint.InboundEndpoint;
import org.mule.api.endpoint.OutboundEndpoint;
import org.mule.api.processor.MessageProcessor;
import org.mule.api.source.MessageSource;
import org.mule.construct.Flow;
import org.mule.management.stats.FlowConstructStatistics;
import org.mule.util.queue.Queue;
import org.mule.util.queue.QueueManager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class QueueDataService implements MuleContextAware
{
    private MuleContext muleContext;
    
    public NodeQueueData generateQueueData(String queues)
    {
        Map<String, QueueData> dataMap = new HashMap<String, QueueData>();
        Collection<FlowConstruct> fcs = muleContext.getRegistry().lookupObjects(FlowConstruct.class);
        for (FlowConstruct fc : fcs)
        {
            if (fc instanceof Flow)
            {
                FlowConstructStatistics fcStats = fc.getStatistics();
                Flow flow = (Flow) fc;
                MessageSource source = flow.getMessageSource();
                if (source instanceof InboundEndpoint)
                {
                    InboundEndpoint ie = (InboundEndpoint) source;
                    String queue = ie.getEndpointURI().getAddress();
                    if ("VM".equals(ie.getProtocol()) && queues.contains(queue))
                    {
                        QueueData qd = getQueueData(dataMap, queue);
                        qd.setTotalOut(fcStats.getTotalEventsReceived());
                    }
                }
                for (MessageProcessor mp : flow.getMessageProcessors())
                {
                    if (mp instanceof OutboundEndpoint)
                    {
                        OutboundEndpoint oe = (OutboundEndpoint) mp;
                        String queue = oe.getEndpointURI().getAddress();
                        if ("VM".equals(oe.getProtocol()) && queues.contains(queue))
                        {
                            QueueData qd = getQueueData(dataMap, queue);
                            qd.setTotalIn(fcStats.getTotalEventsReceived());
                        }                        
                    }
                }
                
            }
        }
        QueueManager tqm = muleContext.getRegistry().lookupObject(MuleProperties.OBJECT_QUEUE_MANAGER);
        for (String queueName : queues.split(","))
        {
            Queue queue = tqm.getQueueSession().getQueue(queueName);
            if (queue != null)
            {
                QueueData queueData = getQueueData(dataMap, queueName);
                queueData.setSize(queue.size());
            }
        }
	//Small improvement to run in standAlone mode
        int clusterNode = muleContext.getClusterNodeId() > 0? muleContext.getClusterNodeId():1;
        return new NodeQueueData(clusterNode, new ArrayList<QueueData>(dataMap.values()));
    }

    private QueueData getQueueData(Map<String, QueueData> dataMap, String queue)
    {
        QueueData queueData = dataMap.get(queue);
        if (queueData == null)
        {
            queueData = new QueueData(queue);
            dataMap.put(queue, queueData);           
        }        
        return queueData;
    }

    public void setMuleContext(MuleContext muleContext)
    {
        this.muleContext = muleContext;
    }
}
