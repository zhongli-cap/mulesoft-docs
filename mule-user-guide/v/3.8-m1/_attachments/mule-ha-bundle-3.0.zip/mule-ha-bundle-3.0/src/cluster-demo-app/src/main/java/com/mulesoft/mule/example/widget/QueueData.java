/*
 * $Id$
 * --------------------------------------------------------------------------------------
 *
 * (c) 2003-2010 MuleSoft, Inc. This software is protected under international copyright
 * law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 * (or other master license agreement) separately entered into in writing between you and
 * MuleSoft. If such an agreement is not in place, you may not use the software.
 */

package com.mulesoft.mule.example.widget;

public class QueueData
{
    private String queueName;
    private int size;
    private long totalIn;
    private long totalOut;

    public QueueData(String queueName)
    {
        this.queueName = queueName;
    }

    public String getQueueName()
    {
        return queueName;
    }

    public int getSize()
    {
        return size;
    }

    public void setSize(int size)
    {
        this.size = size;
    }

    public long getTotalIn()
    {
        return totalIn;
    }

    public void setTotalIn(long totalIn)
    {
        this.totalIn = totalIn;
    }

    public long getTotalOut()
    {
        return totalOut;
    }

    public void setTotalOut(long totalOut)
    {
        this.totalOut = totalOut;
    }
}
